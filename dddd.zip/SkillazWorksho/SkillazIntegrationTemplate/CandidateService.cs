﻿using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace HttpIntegrationTemplate;

public class CandidateService
{
    private readonly HttpClient _httpClient;

    public CandidateService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public void CheckCandidate(string id)
    {
        var candidate = GetCandidateInfo(id);
        var vacancy = GetVacancyInfo(candidate.VacancyId);

        if (CalculateMatching(candidate, vacancy))
        {
            Console.WriteLine("Кандидат подходит к вакансии.");
            AddCommentToCandidate(id, "Подходит");
        }
        else
        {
            Console.WriteLine("Кандидат не подходит к вакансии.");
            AddCommentToCandidate(id, "Не подходит");
        }
    }


    private bool CalculateMatching(CandidateInfo candidateInfo, VacancyInfo vacancyInfo)
    {
        bool skillsMatch = false;
        bool experienceMatches = false;
        bool citizenshipMatches = false;
        bool hasValidLicense = false;

        try
        {
            if (vacancyInfo.Data.RequiredSkills == null)
            {
                skillsMatch = true; // Если требуемые навыки не указаны, считаем, что соответствие есть
            }
            else
            {
                skillsMatch = SkillsMatch(candidateInfo.Skills, vacancyInfo.Data.RequiredSkills);
            }
        }
        catch
        {
            // Обработка возможной ошибки
        }

        try
        {
            if (vacancyInfo.Data.WorkExperience == null)
            {
                experienceMatches = true; // Если требуемый опыт работы не указан, считаем, что соответствие есть
            }
            else
            {
                experienceMatches = ExperienceMatches(candidateInfo.TotalExperience, vacancyInfo.Data.WorkExperience);
            }
        }
        catch
        {
            // Обработка возможной ошибки
        }

        try
        {
            if (vacancyInfo.Data.Citizenship == null)
            {
                citizenshipMatches = true; // Если требуемое гражданство не указано, считаем, что соответствие есть
            }
            else
            {
                citizenshipMatches = CitizenshipMatches(candidateInfo.Citizenship, vacancyInfo.Data.Citizenship);
            }
        }
        catch
        {
            // Обработка возможной ошибки
        }

        try
        {
            hasValidLicense = HasValidDriverLicense(candidateInfo.DriverLicense);
        }
        catch
        {
            // Обработка возможной ошибки
        }

        return skillsMatch && experienceMatches && citizenshipMatches && hasValidLicense;
    }


    private bool SkillsMatch(List<string> candidateSkills, string[] requiredSkills)
    {
        var intersection = candidateSkills.Intersect(requiredSkills, StringComparer.OrdinalIgnoreCase);
        return intersection.Count() >= requiredSkills.Length * 0.7;
    }

    private bool ExperienceMatches(int? candidateExperience, int? requiredExperience)
    {
        if (candidateExperience.HasValue && requiredExperience.HasValue)
        {
            return Math.Abs(candidateExperience.Value - requiredExperience.Value) <= 6;
        }
        return false;
    }

    private bool CitizenshipMatches(string[] candidateCitizenship, string requiredCitizenship)
    {
        return candidateCitizenship.Contains(requiredCitizenship);
    }

    private bool HasValidDriverLicense(string driverLicense)
    {
        return !string.IsNullOrEmpty(driverLicense);
    }





    public CandidateInfo GetCandidateInfo(string id)
    {
        var message = new HttpRequestMessage(HttpMethod.Post, "/open-api/objects/candidates/filtered")
        {
            Content = JsonContent.Create(new CandidateInfoRequest
            {
                Ids = new[] { id }
            }, options: new() { PropertyNamingPolicy = null })
        };

        var response = _httpClient.Send(message);

        if (!response.IsSuccessStatusCode)
        {
            throw new Exception("Ошибка запроса");
        }

        var deserializedResponse = JsonSerializer.Deserialize<CandidateInfoResponse>(response.Content.ReadAsStream());

        return deserializedResponse?.Items.FirstOrDefault() ?? throw new Exception("Не найден кандидат");
    }


    private VacancyInfo GetVacancyInfo(string vacancyId)
    {
        var requestUri = $"/open-api/objects/vacancies/{vacancyId}";
        var requestMessage = new HttpRequestMessage(HttpMethod.Get, requestUri);

        var response = _httpClient.Send(requestMessage);

        if (!response.IsSuccessStatusCode)
        {
            throw new Exception("Ошибка запроса");
        }

        using var responseStream = response.Content.ReadAsStream();
        var vacancyInfo = JsonSerializer.Deserialize<VacancyInfo>(responseStream);

        return vacancyInfo ?? throw new Exception("Не найдена вакансия");
    }


    // Добавление комментария к кандидату
    private void AddCommentToCandidate(string candidateId, string text)
    {
        // Формирование запроса для добавления комментария к кандидату
        var requestUri = $"/open-api/objects/candidates/{candidateId}/notes";
        var requestData = new
        {
            Add = new[]
            {
                    new { Text = text }
                }
        };

        var requestContent = JsonContent.Create(requestData);

        var requestMessage = new HttpRequestMessage(HttpMethod.Post, requestUri)
        {
            Content = requestContent
        };

        var response = _httpClient.Send(requestMessage);

        if (!response.IsSuccessStatusCode)
        {
            throw new Exception("Ошибка добавления комментария");
        }
    }
}

public class CandidateInfoRequest
{
    public string[] Ids { get; set; }
    public CandidateCommonCvInfo CommonCVInfo { get; set; }
}

public class CandidateInfoResponse
{
    public CandidateInfo[] Items { get; set; }
}

public class CandidateInfo
{
    public string VacancyId { get; set; }
    public List<CandidateNote> Notes { get; set; }
    public string Avatar { get; set; }
    public string AvatarFileId { get; set; }
    public string Area { get; set; }
    public string Metro { get; set; }
    public string About { get; set; }
    public string Gender { get; set; }
    public string GenderType { get; set; }
    public DateTime? BirthDate { get; set; }
    public string Education { get; set; }
    public string CurrentTitle { get; set; }
    public string CurrentCompany { get; set; }
    public List<string> Skills { get; set; }
    public string[]? Citizenship { get; set; }
    public int? TotalExperience { get; set; }
    public int? AverageExperience { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public List<string> Comments { get; set; }
    public int? PreferredSalary { get; set; }
    public string ExpectedSalary { get; set; }
    public string ResumeTitle { get; set; }
    public string City { get; set; }
    public string DriverLicense { get; set; }
    public List<string> PreferredEmployments { get; set; }
    public List<string> PreferredSchedules { get; set; }
    public string EducationType { get; set; }
    public string WorkExperienceType { get; set; }
    public List<string> Educations { get; set; }
    public List<string> WorkExperience { get; set; }
    public List<string> Languages { get; set; }
    public string PreferredSchedule { get; set; }
    public string KnownLanguages { get; set; }
    public string PreferredPosition { get; set; }
    public string PreferredEmployment { get; set; }
    public string RelocationReadiness { get; set; }
    public List<string> AdditionalFields { get; set; }
    public bool ContactsHidden { get; set; }
    public string Country { get; set; }
    public List<string> ProfessionalAreas { get; set; }
    public DateTime? CreatedAt { get; set; }
    public string BusinessTripReadiness { get; set; }
    public string WorkTravelTime { get; set; }
    public string JobSearchStatus { get; set; }
    public bool? HasMedcard { get; set; }
    public bool? HasChildren { get; set; }
    public string RelocationRegions { get; set; }
    public List<string> SocialMedia { get; set; }
    public List<string> DrivingExperiences { get; set; }
    public string MaritalStatus { get; set; }
    public List<string> Recommendations { get; set; }
}


public class CandidateCommonCvInfo
{
    public string[] Citizenship { get; set; }
    public CandidateWorkExperience[] WorkExperience { get; set; }
    public string Avatar { get; set; }
    public string AvatarFileId { get; set; }
    public string Area { get; set; }
    public string Metro { get; set; }
    public string Gender { get; set; }
    public string GenderType { get; set; }
    public string CurrentTitle { get; set; }
    public DateTime? BirthDate { get; set; }
    public string Education { get; set; }
    public string[] Skills { get; set; }
    public string FirstCitizenship { get; set; }
    public bool? WasUpdated { get; set; }
    public int? TotalExperience { get; set; }
    public int? AverageExperience { get; set; }
    public string About { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string CurrentCompany { get; set; }
    public int? PreferredSalary { get; set; }
    public string ResumeTitle { get; set; }
    public string[] PreferredEmployments { get; set; }
    public string[] PreferredSchedules { get; set; }
    public string[] Educations { get; set; }
    public string EducationType { get; set; }
    public string WorkExperienceType { get; set; }
    public string[] Languages { get; set; }
    public string City { get; set; }
    public string Country { get; set; }
    public bool? IsRelocationNeeded { get; set; }
    public string PreferredSchedule { get; set; }
    public string KnownLanguages { get; set; }
    public string ExpectedSalary { get; set; }
    public string PreferredPosition { get; set; }
    public string PreferredEmployment { get; set; }
    public string RelocationReadiness { get; set; }
    public string DriverLicense { get; set; }
    [Obsolete]
    public bool? ContactsHidden { get; set; }
    public string[] ProfessionalAreas { get; set; }
    public string ResumeText { get; set; }
    public DateTime? CreatedAt { get; set; }
    public string BusinessTripReadiness { get; set; }
    public string WorkTravelTime { get; set; }
    public string JobSearchStatus { get; set; }
    public bool? HasMedcard { get; set; }
    public bool? HasChildren { get; set; }
    public string RelocationRegions { get; set; }
    public string[] SocialMedia { get; set; }
    public string[] DrivingExperiences { get; set; }
    public string MaritalStatus { get; set; }
    public string[] Recommendations { get; set; }
}
public class CandidateWorkExperience
{
    public string CompanyName { get; set; }
    private int TotalMonths { get; set; }
}

public class CandidateNote
{
    public string Id { get; set; }
    public string Text { get; set; }
    public DateTime CreatedAt { get; set; }
}


public class VacancyInfo
{
    public string Id { get; set; }
    public string Name { get; set; }
    public bool IsActive { get; set; }
    public string FunnelId { get; set; }
    public AuditInfo Audit { get; set; }
    public VacancyData Data { get; set; }
    public RefsInfo Refs { get; set; }
}

public class AuditInfo
{
    public DateTime CreatedAt { get; set; }
    public string CreatedBy { get; set; }
    public string CreatedByName { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string UpdatedBy { get; set; }
    public string UpdatedByName { get; set; }
}

public class VacancyData
{
    public string Name { get; set; }
    public string FunnelId { get; set; }
    [JsonPropertyName("ExtraData.RequiredSkills")]
    public string[]? RequiredSkills { get; set; }
    [JsonPropertyName("ExtraData.WorkExperience")]
    public int? WorkExperience { get; set; }
    [JsonPropertyName("ExtraData.Citizenship")]
    public string? Citizenship { get; set; }

}

public class ExtraDataInfo
{
    public int? WorkExperience { get; set; }
    public string Citizenship { get; set; }
    public bool NeedDriverLicense { get; set; }
}

public class RefsInfo
{
    public string Application { get; set; }
}
